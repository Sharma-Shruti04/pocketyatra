import { User } from "../models/User.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { OAuth2Client } from "google-auth-library";
import dotenv from "dotenv";

dotenv.config();
const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

// ------------------ SIGNUP ------------------
export const handleSignup = async (req, res) => {
  try {
    const { email, password, name } = req.body;
    if (!email || !password) {
      res.writeHead(400, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "All fields required" }));
    }

    // Check if user exists
    let existing = await User.findOne({ email });
    if (existing) {
      res.writeHead(400, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "User already exists" }));
    }

    const hashed = await bcrypt.hash(password, 10);
    const user = new User({ email, password: hashed, name });
    await user.save();

    res.writeHead(201, { "Content-Type": "application/json" });
    return res.end(JSON.stringify({ message: "User created", user }));
  } catch (err) {
    console.error("Signup error:", err);
    res.writeHead(500, { "Content-Type": "application/json" });
    return res.end(JSON.stringify({ message: "Server error", error: err.message }));
  }
};

// ------------------ LOGIN ------------------
export const handleLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      res.writeHead(400, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "All fields required" }));
    }

    const user = await User.findOne({ email });
    if (!user) {
      res.writeHead(400, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "User not found" }));
    }

    const isMatch = await bcrypt.compare(password, user.password || "");
    if (!isMatch) {
      res.writeHead(400, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "Invalid credentials" }));
    }

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: "2h" });

    res.writeHead(200, { "Content-Type": "application/json" });
    return res.end(JSON.stringify({ message: "Login successful", token, user }));
  } catch (err) {
    console.error("Login error:", err);
    res.writeHead(500, { "Content-Type": "application/json" });
    return res.end(JSON.stringify({ message: "Server error", error: err.message }));
  }
};

// ------------------ GOOGLE LOGIN ------------------
export const handleGoogleLogin = async (req, res) => {
  try {
    const { tokenId } = req.body;
    if (!tokenId) {
      res.writeHead(400, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "No Google token provided" }));
    }

    // Verify token with Google
    const ticket = await googleClient.verifyIdToken({
      idToken: tokenId,
      audience: process.env.GOOGLE_CLIENT_ID,
    });
    const payload = ticket.getPayload();
    const { email, sub: googleId, name } = payload;

    // Find or create user
    let user = await User.findOne({ email });
    if (!user) {
      user = new User({ email, name, googleId });
      await user.save();
    }

    // Create JWT
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: "2h" });

    res.writeHead(200, { "Content-Type": "application/json" });
    return res.end(JSON.stringify({ message: "Google login successful", token, user }));
  } catch (err) {
    console.error("Google login error:", err);
    res.writeHead(500, { "Content-Type": "application/json" });
    return res.end(JSON.stringify({ message: "Google login failed", error: err.message }));
  }
};







// import { User } from "../models/User.js";
// import bcrypt from "bcryptjs";
// import jwt from "jsonwebtoken";
// import { OAuth2Client } from "google-auth-library";
// import dotenv from "dotenv";

// dotenv.config();
// const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

// // ------------------ SIGNUP ------------------
// export const handleSignup = async (req, res) => {
//   try {
//     const { email, password, name } = req.body;
//     if (!email || !password)
//       return res.writeHead(400).end(JSON.stringify({ message: "All fields required" }));

//     const existing = await User.findOne({ email });
//     if (existing)
//       return res.writeHead(400).end(JSON.stringify({ message: "User already exists" }));

//     const hashed = await bcrypt.hash(password, 10);
//     const user = new User({ email, password: hashed, name });
//     await user.save();

//     res.writeHead(201, { "Content-Type": "application/json" });
//     res.end(JSON.stringify({ message: "Signup successful" }));
//   } catch (err) {
//     res.writeHead(500);
//     res.end(JSON.stringify({ message: "Server error", error: err.message }));
//   }
// };

// // ------------------ LOGIN ------------------
// export const handleLogin = async (req, res) => {
//   try {
//     const { email, password } = req.body;
//     const user = await User.findOne({ email });
//     if (!user)
//       return res.writeHead(400).end(JSON.stringify({ message: "User not found" }));

//     const isMatch = await bcrypt.compare(password, user.password);
//     if (!isMatch)
//       return res.writeHead(400).end(JSON.stringify({ message: "Invalid credentials" }));

//     const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: "1h" });

//     res.writeHead(200, { "Content-Type": "application/json" });
//     res.end(JSON.stringify({ message: "Login successful", token }));
//   } catch (err) {
//     res.writeHead(500);
//     res.end(JSON.stringify({ message: "Server error", error: err.message }));
//   }
// };

// // ------------------ GOOGLE LOGIN ------------------
// export const handleGoogleLogin = async (req, res) => {
//   try {
//     const { credential } = req.body;
//     if (!credential)
//       return res.writeHead(400).end(JSON.stringify({ message: "No Google token provided" }));

//     // Verify Google token
//     const ticket = await googleClient.verifyIdToken({
//       idToken: credential,
//       audience: process.env.GOOGLE_CLIENT_ID,
//     });

//     const payload = ticket.getPayload();
//     const { email, name, sub: googleId } = payload;

//     // Check or create user
//     let user = await User.findOne({ email });
//     if (!user) {
//       user = new User({ email, name, googleId });
//       await user.save();
//     }

//     // Create JWT
//     const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: "2h" });

//     res.writeHead(200, { "Content-Type": "application/json" });
//     res.end(JSON.stringify({ message: "Google login successful", token, user }));
//   } catch (err) {
//     res.writeHead(500);
//     res.end(JSON.stringify({ message: "Google login failed", error: err.message }));
//   }
// };

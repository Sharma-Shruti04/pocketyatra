// import dotenv from "dotenv";
// import { GoogleGenerativeAI } from "@google/generative-ai";
// import { parseJSON } from "../middlewares/bodyParser.js";

// dotenv.config();

// const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
// const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

// export const handleFlightSearch = async (req, res) => {
//   try {
//     const body = await parseJSON(req);
//     const { origin, destination, departureDate, returnDate } = body;

//     if (!origin || !destination || !departureDate) {
//       res.writeHead(400, { "Content-Type": "application/json" });
//       return res.end(JSON.stringify({ message: "Missing required fields" }));
//     }

//     const prompt = `
//     Find flights from ${origin} to ${destination}
//     departing on ${departureDate}${returnDate ? ` and returning on ${returnDate}` : ""}.
//     Include:
//     - Airline name
//     - Departure and arrival times
//     - Flight duration
//     - Price in INR
//     Return output as a valid JSON array.
//     `;

//     const result = await model.generateContent(prompt);
//     const text = result.response.text();

//     let flights;
//     try {
//       flights = JSON.parse(text);
//     } catch {
//       flights = [{ note: "Unable to parse Gemini output", raw: text }];
//     }

//     res.writeHead(200, { "Content-Type": "application/json" });
//     res.end(JSON.stringify({ success: true, flights }));
//   } catch (err) {
//     console.error("Flight search error:", err);
//     res.writeHead(500, { "Content-Type": "application/json" });
//     res.end(JSON.stringify({ success: false, error: err.message }));
//   }
// };




// backend/controllers/flightController.js
import axios from "axios";
import dotenv from "dotenv";

dotenv.config();

export const searchFlights = async (req, res) => {
  try {
    const { from, to, depart, returnDate } = req.body;

    if (!from || !to || !depart) {
      return res.status(400).json({
        success: false,
        message: "Missing required fields: from, to, or depart date",
      });
    }

    // ✈️ Dummy data fallback if no Gemini API key
    if (!process.env.GEMINI_API_KEY) {
      const dummyFlights = [
        {
          airline: "IndiGo",
          departure_time: "08:30 AM",
          arrival_time: "10:45 AM",
          duration: "2h 15m",
          price_in_inr: 4899,
        },
        {
          airline: "Air India",
          departure_time: "11:45 AM",
          arrival_time: "02:10 PM",
          duration: "2h 25m",
          price_in_inr: 5250,
        },
        {
          airline: "SpiceJet",
          departure_time: "06:00 PM",
          arrival_time: "08:15 PM",
          duration: "2h 15m",
          price_in_inr: 4999,
        },
      ];

      return res.json({ success: true, data: dummyFlights });
    }

    // 🧠 Gemini API request
    const response = await axios.post(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${process.env.GEMINI_API_KEY}`,
      {
        contents: [
          {
            parts: [
              {
                text: `List 3 flights from ${from} to ${to} on ${depart}${
                  returnDate ? ` returning on ${returnDate}` : ""
                } with airline name, departure time, arrival time, duration, and price in INR in JSON array format.`,
              },
            ],
          },
        ],
      }
    );

    const text =
      response.data.candidates?.[0]?.content?.parts?.[0]?.text || "[]";

    let parsedData;
    try {
      parsedData = JSON.parse(text);
    } catch {
      parsedData = [{ note: "Unable to parse Gemini output", raw: text }];
    }

    res.json({ success: true, data: parsedData });
  } catch (error) {
    console.error("Error fetching flights:", error.message);
    res.status(500).json({
      success: false,
      message: "Failed to fetch flight data",
    });
  }
};


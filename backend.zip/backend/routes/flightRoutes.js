import { searchFlights } from "../controllers/flightController.js";
import { parseJSON } from "../middlewares/bodyParser.js";

export const handleFlightRoutes = async (req, res) => {
  if (req.url === "/api/flights" && req.method === "POST") {
    try {
      const body = await parseJSON(req);
      req.body = body;
      return searchFlights(req, res);
    } catch (err) {
      res.writeHead(400, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ success: false, message: "Invalid JSON" }));
    }
  }
  return false; // route not handled
};
